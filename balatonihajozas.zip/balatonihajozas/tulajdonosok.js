async function Tulajdonosok() {
    try {
        let valasz = await fetch("/api/tulajdonosok")
        let adatok = await valasz.json()
        let select = document.getElementById("tulajdonos")
        select.innerHTML = adatok.map(t => `<option value="${t.id}">${t.nev}</option>`).join("")
    } catch (error) {
        console.error(error)
    }
}

async function Tipusok() {
    try {
        let valasz = await fetch("/api/tipusok")
        let adatok = await valasz.json()
        let select = document.getElementById("tipus")
        select.innerHTML = adatok.map(t => `<option value="${t.id}">${t.tipus}</option>`).join("")
    } catch (error) {
        console.error(error)
    }
}

async function urlap() {
    let alertContainer = document.getElementById("alertContainer");
    try {
        let valasz = await fetch("/api/ujhajo", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                "hajoNev" : document.getElementById("hajoNev").value,
                "tulaz" : document.getElementById("tulajdonos").value,
                "tipus" : document.getElementById("tipus").value,
                "uzemel" : document.querySelector("input[name='uzemel']:checked")?.value
        })
        });
        let eredm = await valasz.json();
        if (!valasz.ok) {
            alertContainer.innerHTML = `<div class='alert alert-danger'>${eredm.message}</div>`;
        } else {
            alertContainer.innerHTML = `<div class='alert alert-success'>Sikeres rögzítés! Azonosító: ${eredm.id}</div>`;
            document.getElementById("hajoForm").reset();
        }
    } catch (error) {
        //alertContainer.innerHTML = `<div class='alert alert-danger'>Hiba történt a küldés során.</div>`;
        console.error(error);
    }
}

window.addEventListener("load", () => {
    Tulajdonosok()
    Tipusok()
})

document.getElementById("rogzit").addEventListener('click', urlap)