async function tipusok() {
    try {
        let adatok = await fetch("/api/varosok");
        let varosok = await adatok.json();
        Feltolt(varosok);
        
    } catch (error) {
        console.log(error);
    }
}

function Feltolt(varosok){
    let option = document.getElementById("valasztott");
    for(let varos of varosok){
        option.innerHTML += 
        `
            <option value="${varos.varos}">${varos.varos}</option>
        `;
    }
}

async function adatokLeker(){
    let valasztottVaros = document.getElementById("valasztott").value;
    
    try {
        let adatok = await fetch(`/api/varostulajdonos`, {
            method : "POST",
            headers : {'Content-Type' : 'application/json'},
            body : JSON.stringify({
                "nev" : valasztottVaros
            })
        });

        let varosok_ = await adatok.json();
        Kiir(varosok_);
    } catch (error) {
        console.log(error);
    }
}

function Kiir(varosok_){
    let lista = document.getElementById("lista");
    lista.innerHTML = "";
    for (let varos of varosok_.valasz) {
        lista.innerHTML += 
        `
            <li class="list-group-item"><strong>${varos.nev}</strong> hajók száma: ${varos.hajokszama}</li>
        `;
    }
}

window.addEventListener('load', tipusok)