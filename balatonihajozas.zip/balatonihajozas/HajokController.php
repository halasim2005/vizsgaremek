<?php

namespace App\Http\Controllers;

use App\Models\Hajok;
use Illuminate\Http\Request;


class HajokController extends Controller
{
    public static function tipusok(){
        $tipusok = Hajok::TipusokDB();
        if(!$tipusok) return response() -> json(["valasz" => "Nincsenek adatok!"], 405, [], JSON_UNESCAPED_UNICODE);
        else return response() -> json($tipusok, 200, [], JSON_UNESCAPED_UNICODE);
    }

    public static function hajok(Request $request){
        $tipus = $request->input('tipus');

        if(!$tipus){
            return response()->json(["valasz" => "Hiányos adatok!"], 400, [], JSON_UNESCAPED_UNICODE);
        }

        $lekertAdatok = hajok::HajokDB($tipus);
        
        if($lekertAdatok){
            return response()->json(["valasz" => $lekertAdatok], 200, [], JSON_UNESCAPED_UNICODE);
        }
    }

    public static function ujhajo(Request $request){
        $nev = $request -> input('nev');
        $tipus = $request -> input('tipus');
        $tulaz = $request -> input('tulaz');
        $uzemel = $request -> input('uzemel');

        if($nev == "" || $tipus == "" || $tulaz == "" || $uzemel == "") return response() -> json("Hiányos adatok!", 400, [], JSON_UNESCAPED_UNICODE);

        $ujhajo = Hajok::UjhajoDB($nev, $tipus, $tulaz, $uzemel);

        if($ujhajo){
            $azLeker = Hajok::AzlekerDB();
            return response() -> json(["valasz" => $azLeker], 201, [], JSON_UNESCAPED_UNICODE);
        }else{
            return response() -> json("Nincsenek adatok!", 400, [], JSON_UNESCAPED_UNICODE);
        }
    }
}