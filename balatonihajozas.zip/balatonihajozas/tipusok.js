async function tipusok() {
    try {
        let adatok = await fetch("/api/tipusok");
        let tipusok = await adatok.json();
        Kiir(tipusok);
        
    } catch (error) {
        console.log(error);
    }
}

function Kiir(tipusok){
    let torzs = document.getElementById("torzs");
    let id = 1;
    for(let tipus of tipusok){
        torzs.innerHTML += 
        `
            <tr class="text-center">
                <td scope="col">${id}</td>
                <td scope="col"><button type="button" onclick="hajok('${tipus.tipus}')" id="gomb">${tipus.tipus}</button></td>
                <td scope="col">${tipus.db}</td>
            </tr>
        `;
        id++;
    }
}

async function hajok(tipus){
    try {
        let adatok = await fetch(`/api/hajok?tipus=${tipus}`);
        let hajok = await adatok.json();
        Kartyak(hajok);
        console.log(hajok);
        
    } catch (error) {
        console.log(error);
    }
}

function Kartyak(hajok){
    let kartyak = document.getElementById("kartyak");
    let valasz = document.getElementById("valasz");
    kartyak.innerHTML = "";
    valasz.style.display = "none";
    for(let hajo of hajok.valasz){
        kartyak.innerHTML += 
        `
        <div class="col-6">
            <div class="card my-1">
                <div class="card-body">
                    <h3 style="color: red">${hajo.hajoNev}</h3>
                    <p><span style="font-weight: bold">Tulajdonos:</span> ${hajo.nev}
                    <br>${hajo.uzemel == 1 ? "Üzemel" : "Nem üzemel"}</p>
                </div>
            </div>
        </div>
        `;
    }
}

window.addEventListener('load', tipusok)