<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HajokController;
use App\Http\Controllers\TulajdonosokController;

Route::get('/tipusok', [HajokController::class, 'tipusok']);

Route::get('/hajok', [HajokController::class, 'hajok']);

Route::get('/tulajdonosok', [TulajdonosokController::class, 'tulajdonosok']);

Route::get('/varosok', [TulajdonosokController::class, 'varosok']);

Route::post('/varostulajdonos', [TulajdonosokController::class, 'varostulajdonos']);

Route::post('/ujhajo', [HajokController::class, 'ujhajo']);

