<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Tulajdonosok extends Model
{
    public static function TulajdonosokDB(){
        return DB::select("SELECT tulajdonos.az, tulajdonos.nev FROM tulajdonos ORDER BY tulajdonos.nev;");
    }

    public static function VarosokDB(){
        return DB::select("SELECT DISTINCT tulajdonos.varos FROM tulajdonos ORDER BY tulajdonos.varos;");
    }

    public static function VarostulajdonosDB($nev){
        return DB::select("SELECT tulajdonos.nev, COUNT(hajok.uzemel) AS hajokszama FROM tulajdonos INNER JOIN hajok ON hajok.tulaz = tulajdonos.az WHERE tulajdonos.varos = ? GROUP BY tulajdonos.nev;", [$nev]);
    }
}