<?php

namespace App\Http\Controllers;

use App\Models\Tulajdonosok;
use Illuminate\Http\Request;

class TulajdonosokController extends Controller
{
    public static function tulajdonosok(){
        $tulajok = Tulajdonosok::TulajdonosokDB();
        if(!$tulajok) return response() -> json(["valasz" => "Nincsenek adatok!"], 405, [], JSON_UNESCAPED_UNICODE);
        else return response() -> json($tulajok, 200, [], JSON_UNESCAPED_UNICODE);
    }

    public static function varosok(){
        $varosok = Tulajdonosok::VarosokDB();
        if(!$varosok) return response() -> json(["valasz" => "Nincsenek adatok!"], 405, [], JSON_UNESCAPED_UNICODE);
        else return response() -> json($varosok, 200, [], JSON_UNESCAPED_UNICODE);
    }

    public static function varostulajdonos(Request $request){
        $varosNev = $request->input('nev');

        if($varosNev == ""){
            return response()->json(["valasz" => "Hiányos adatok!"], 400, [], JSON_UNESCAPED_UNICODE);
        }

        $lekerAdatVT = Tulajdonosok::VarostulajdonosDB($varosNev);

        if($lekerAdatVT){
            return response()->json(["valasz" => $lekerAdatVT], 200, [], JSON_UNESCAPED_UNICODE);
        }else{
            return response()->json(["valasz" => "Nincsenek adatok!"], 400, [], JSON_UNESCAPED_UNICODE);
        }
    }
}