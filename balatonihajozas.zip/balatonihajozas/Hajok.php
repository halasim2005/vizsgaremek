<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Hajok extends Model
{
    public static function TipusokDB(){
        return DB::select("SELECT tipus, COUNT(tipus) AS db FROM hajok GROUP BY tipus ORDER BY db DESC;");
    }

    public static function HajokDB($tipus){
        return DB::select("SELECT hajok.nev as hajoNev, tulajdonos.nev, uzemel FROM hajok, tulajdonos WHERE tulajdonos.az = hajok.tulaz AND hajok.tipus = ?;", [$tipus]);
    }

    public static function UjhajoDB($nev, $tipus, $tulaz, $uzemel){
        return DB::insert("INSERT INTO hajok (nev, tipus, tulaz, uzemel) VALUES (?, ?, ?, ?)", [$nev, $tipus, $tulaz, $uzemel]);
    }

    public static function AzlekerDB(){
        return DB::select("SELECT hajok.az FROM `hajok` ORDER BY hajok.az DESC LIMIT 1;");
    }
}